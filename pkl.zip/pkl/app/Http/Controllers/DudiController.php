<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Dudi; // Import model Dudi

class DudiController extends Controller
{
    public function index()
    {
        //get posts
        $dudis = Dudi::latest()->paginate(5);

        //render view with posts
        return view('dudis.index', compact('dudis'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dudis.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validate form
        $this->validate($request, [
            'nama_pkl'     => 'required|min:5',
            'alamat'   => 'required|min:5'
        ]);

        //create post
        Dudi::create([
            'nama_pkl'     => $request->nama_pkl,
            'alamat'   => $request->alamat
        ]);

        //redirect to index
        return redirect()->route('dudis.index')->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Dudi $dudi)
    {
        return view('dudis.edit', compact('dudi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Dudi $dudi)
    {
         //validate form
         $this->validate($request, [
            'nama_pkl'     => 'required|min:5',
            'alamat'   => 'required|min:5'
        ]);

        
            //update post without image
            $dudi->update([
                'nama_pkl'     => $request->nama_pkl,
                'alamat'   => $request->alamat
            ]);

        //redirect to index
        return redirect()->route('dudis.index')->with(['success' => 'Data Berhasil Diubah!']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Dudi $dudi)
    {
        //delete post
        $dudi->delete();
 
        //redirect to index
        return redirect()->route('dudis.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
