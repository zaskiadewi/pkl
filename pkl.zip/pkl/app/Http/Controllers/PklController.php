<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pkl; // Mengimpor model Pkl
use App\Models\Siswa; // Mengimpor model Siswa
use App\Models\Dudi; // Mengimpor model Dudi

class PklController extends Controller
{
    public function index()
    {
        //get posts
        $pkls = Pkl::latest()->paginate(5);

        //render view with posts
        return view('pkls.index', compact('pkls'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $siswas = Siswa::all();
        $dudis = Dudi::all();

        return view('pkls.create', compact('siswas', 'dudis'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate form data
        $request->validate([
            'id_siswa' => 'required',
            'id_dudi' => 'required',
            'tgl_masuk' => 'required|date_format:Y-m-d\TH:i',
            'tgl_keluar' => 'nullable|date_format:Y-m-d\TH:i|after_or_equal:tgl_masuk',
        ]);
    
        // Create a new Peminjaman instance
        Pkl::create([
            'id_siswa' => $request->id_siswa,
            'id_dudi' => $request->id_dudi,
            'tgl_masuk' => $request->tgl_masuk,
            'tgl_keluar' => $request->tgl_keluar,
        ]);
    
        // Redirect to the index page with a success message
        return redirect()->route('pkls.index')->with('success', 'Data Peminjaman Berhasil Disimpan!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Pkl $pkl)
    {
        $siswas = Siswa::all();
        $dudis = Dudi::all();

        return view('pkls.edit', compact('pkl', 'siswas', 'dudis'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pkl $pkl)
    {
        // Validate form data
        $request->validate([
            'id_siswa' => 'required',
            'id_dudi' => 'required',
            'tgl_masuk' => 'required|date_format:Y-m-d\TH:i',
            'tgl_keluar' => 'nullable|date_format:Y-m-d\TH:i|after_or_equal:tgl_masuk',
        ]);
    
        // Update Peminjaman instance
        $pkl->update([
            'id_siswa' => $request->id_siswa,
            'id_dudi' => $request->id_dudi,
            'tgl_masuk' => $request->tgl_masuk,
            'tgl_keluar' => $request->tgl_keluar,
        ]);
    
        // Redirect to the index page with a success message
        return redirect()->route('pkls.index')->with('success', 'Data Peminjaman Berhasil Diperbarui!');
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pkl $pkl)
    {
        $pkl->delete();
 
        return redirect()->route('pkls.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
